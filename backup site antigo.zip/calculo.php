<!doctype html>
<html lang="pt-br">

<head>
    <title>Aulas de Cálculo</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/global_css.css">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <?php include_once("menu.php")  ?>
    <div class="submenu">
        <div class="regulasub">
            <a class="btn btn-dark" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false"
                aria-controls="collapseExample">
                <h3 class="text-info"><img src="caderneta.png" class="subimagem" />
                </h3>
            </a>
        </div>
        <div class="collapse bg-dark" id="collapseExample">
            <ul class="subcont text-white" style="list-style:none; text-align:right;">
                <a href="#aula1" class="text-white">
                    <li><b>Aula 01 - 17/08/2020</b></li>
                </a>
                <a href="#aula2" class="text-white">
                    <li><b>Aula 02 - 18/08/2020</b></li>
                </a>
                <a href="#aula3" class="text-white">
                    <li><b>Aula 03 - 24/08/2020</b></li>
                </a>
                <a href="#aula4" class="text-white">
                    <li><b>Aula 04 - 25/08/2020</b></li>
                </a>
                <a href="#aula5" class="text-white">
                    <li><b>Aula 05 - 31/08/2020</b></li>
                </a>
                <a href="#aula6" class="text-white">
                    <li><b>Aula 06 - 01/09/2020</b></li>
                </a>
                <a href="#aula7" class="text-white">
                    <li><b>Aula 07 - 08/09/2020</b></li>
                </a>
                <a href="#aula8" class="text-white">
                    <li><b>Aula 08 - 15/09/2020</b></li>
                </a>
                <a href="#aula9" class="text-white">
                    <li><b>Aula 09 - 21/09/2020</b></li>
                </a>
                <a href="#aula10" class="text-white">
                    <li><b>Aula 10 - 22/09/2020</b></li>
                </a>
                <a href="#aula11" class="text-white">
                    <li><b>Aula 11 - 28/09/2020</b></li>
                </a>
                <a href="#aula12" class="text-white">
                    <li><b>Aula 12 - 29/09/2020</b></li>
                </a>
                <a href="#aula13" class="text-white">
                    <li><b>Aula 13 - 05/10/2020</b></li>
                </a>
                <a href="#aula14" class="text-white">
                    <li><b>Aula 14 - 06/10/2020</b></li>
                </a>
                <a href="#aula15" class="text-white">
                    <li><b>Aula 15 - 19/10/2020</b></li>
                </a>
                <a href="#aula16" class="text-white">
                    <li><b>Aula 16 - 20/10/2020</b></li>
                </a>
                <a href="#aula17" class="text-white">
                    <li><b>Aula 17 - 26/10/2020</b></li>
                </a>
                <a href="#aula18" class="text-white">
                    <li><b>Aula 18 - 27/10/2020</b></li>
                </a>
                <a href="#aula19" class="text-white">
                    <li><b>Aula 19 - 03/11/2020</b></li>
                </a>
                <a href="#aula20" class="text-white">
                    <li><b>Aula 20 - 16/11/2020</b></li>
                </a>
                <a href="#aula21" class="text-white">
                    <li><b>Aula 21 - 17/11/2020</b></li>
                </a>
                <a href="#aula22" class="text-white">
                    <li><b>Aula 22 - 23/11/2020</b></li>
                </a>
                <a href="#aula23" class="text-white">
                    <li><b>Aula 23 - 24/11/2020</b></li>
                </a>
                <a href="#aula24" class="text-white">
                    <li><b>Aula 24 - 28/11/2020</b></li>
                </a>
                <a href="#aula25" class="text-white">
                    <li><b>Aula 25 - 30/11/2020</b></li>
                </a>
                <a href="#aula26" class="text-white">
                    <li><b>Aula 26 - 01/12/2020</b></li>
                </a>
            </ul>
        </div>
    </div>  
    <div class="backgroundwpp">
    <div class="container">
      <div class="col-sm-11 abaixar2 col-lg-10 border border-primary rounded text-white">
            <h5> 
            <b class="text-dark">Prova 1 14/09</b> - Pré calculo</li></ul><br />
            <b class="text-dark">Prova 2 13/10</b> - > Noção Intuitiva de Limites  <br />
                                                     > Calculo Numérico de Limites  <br />
                                                     > Limites Infinitos <br />
            <b class="text-dark">Prova 3 30/11</b> - "Começa onde parou a segunda" <br /></h5>
      </div>
    </div>
        <div class="container">
            <div class="col-sm-12 col-lg-10">
              <h3 id="aula1" > Aula 01 - 17/08/2020 - Plano Cartesiano e Função Afim </h3>
              <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula1">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula1'])){
                          setcookie("ck-aula1-cal", "Verificado", (time() + (3600*24*30*12)));
                          header("Location: #aula1");
                          return 0;
                        }
                        if(isset($_COOKIE['ck-aula1-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
                <a href="https://www.youtube.com/embed/dm2-3B9glXQ" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/dm2-3B9glXQ" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula2"> Aula 02 - 18/08/2020 - Função Afim (Inequações) e Função Quadrática </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula2">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula2'])){
                        
                          setcookie("ck-aula2-cal", "Verificado2", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula2-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
                <a href="https://www.youtube.com/embed/9kJKBgMJpKw" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/9kJKBgMJpKw" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula3"> Aula 03 - 24/08/2020 - Marcou Prova e Função Quadrática </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula3">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula3'])){
                        
                          setcookie("ck-aula3-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula3-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
                <a href="https://www.youtube.com/embed/OP1UgNFYcHc" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/OP1UgNFYcHc" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula4"> Aula 04 - 25/08/2020 - Funções Exponencial e Logarítmica </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula4">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula4'])){
                        
                          setcookie("ck-aula4-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula4-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
                <a href="https://www.youtube.com/embed/tEt3ibuK_qQ" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/tEt3ibuK_qQ" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula5"> Aula 05 - 31/08/2020 - Função Logarítmica </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula5">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula5'])){
                        
                          setcookie("ck-aula5-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula5-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
                <a href="https://www.youtube.com/embed/p5VHHFoNads" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/p5VHHFoNads" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula6"> Aula 06 - 01/09/2020 - Fim de Logarítmo e preparação para Limite </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula6">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula6'])){
                        
                          setcookie("ck-aula6-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula6-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
                <a href="https://www.youtube.com/embed/_5iGyGMFOn0" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/_5iGyGMFOn0" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula7"> Aula 07 - 08/09/2020 - Conceitos básicos de Limite (Vídeo Indisponível)</h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula7">Marcar como estudado</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula7'])){
                        
                          setcookie("ck-aula7-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula7-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
                <ul>
                        <li>Correção dos exercícios anteriores</li>
                        <li>Introdução A Limites</li>
                </ul>
            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula8"> Aula 08 - 15/09 - Limite </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula8-1">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula8-1'])){
                        
                          setcookie("ck-aula8-1-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula8-1-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/nMF5KwYqlZU" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/nMF5KwYqlZU" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>
           
            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula9"> Aula 09 - 21/09 - Função Contínua </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula9">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula9'])){
                        
                          setcookie("ck-aula9-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula9-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/G7Ql9UgIwjU" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/G7Ql9UgIwjU" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula10"> Aula 10 - 22/09 - Teoria da troca e exemplos </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula10">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula10'])){
                        
                          setcookie("ck-aula10-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula10-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/g2kgueS9_ec" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                <iframe width="720" height="480" src="https://www.youtube.com/embed/g2kgueS9_ec" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula11"> Aula 11 - 28/09 - Exemplos de resolução com conjugado e exercícios </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula11">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula11'])){
                        
                          setcookie("ck-aula11-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula11-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/YpUR9hK2KGk" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
              <iframe width="720" height="480" src="https://www.youtube.com/embed/YpUR9hK2KGk" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>


            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula12"> Aula 12 - 29/09 - Exercícios e Introdução A limites Infinitos </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula12">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula12'])){
                        
                          setcookie("ck-aula12-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula12-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/75Ye-OaqFn4" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/75Ye-OaqFn4" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula13"> Aula 13 (SEM ÁUDIO) - 05/10 - Limites Infinitos e Exercícios </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula13">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula13'])){
                        
                          setcookie("ck-aula13-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula13-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/u-NkPT_8U_o" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/u-NkPT_8U_o" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula14"> Aula 14 - 05/10 - Exercicios de Limites Infinitos, Informações da Prova e Introdução a Derivada </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula14">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula14'])){
                        
                          setcookie("ck-aula14-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula14-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/MyWI8jguqLE" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/MyWI8jguqLE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula15"> Aula 15 - 19/10 - Teorema do Confronto </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula15">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula15'])){
                        
                          setcookie("ck-aula15-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula15-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/n4G9zCawPaM" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/n4G9zCawPaM" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula16"> Aula 16 - 19/10 - Lista de exercícios </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula16">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula16'])){
                        
                          setcookie("ck-aula16-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula16-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/Iu3HpIAJC08" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/Iu3HpIAJC08" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>


            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula17"> Aula 17 - 26/10 - Derivada </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula17">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula17'])){
                        
                          setcookie("ck-aula17-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula17-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/N07YoJio8ag" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/N07YoJio8ag" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula18"> Aula 18 - 27/10 - Fórmulas de Derivada </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula18">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula18'])){
                        
                          setcookie("ck-aula18-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula18-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/Av_tSJ9KwoA" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/Av_tSJ9KwoA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula17"> Aula 17 - 26/10 - Derivada </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula17">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula17'])){
                        
                          setcookie("ck-aula17-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula17-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/N07YoJio8ag" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/N07YoJio8ag" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula19"> Aula 19 - 03/11 - Derivadas </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula19">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula19'])){
                        
                          setcookie("ck-aula19-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula19-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/spyP1HH-Zz4" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/spyP1HH-Zz4" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula20"> Aula 20 - 16/11 - Derivadas </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula20">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula20'])){
                        
                          setcookie("ck-aula20-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula20-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/i5GheQnFnJ8" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/i5GheQnFnJ8" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula21"> Aula 21 - 17/11 - Derivadas/ Introdução a Integrais </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula21">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula21'])){
                        
                          setcookie("ck-aula21-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula21-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/p1CcskT_LAA" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/p1CcskT_LAA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula22"> Aula 22 - 23/11 - Integrais </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula22">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula22'])){
                        
                          setcookie("ck-aula22-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula22-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/Cbk7AtGtCYM" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/Cbk7AtGtCYM" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula23"> Aula 23 - 24/11 - Integrais Com Substituição por U</h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula23">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula23'])){
                        
                          setcookie("ck-aula23-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula23-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/nqC9Skkj8ug" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="727" height="409" src="https://www.youtube.com/embed/nqC9Skkj8ug" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>
            
            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula24"> Aula 24 - 28/11 </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula24">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula24'])){
                        
                          setcookie("ck-aula24-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula24-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/eMKFT1mIokk" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/eMKFT1mIokk" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula25"> Aula 25 - 30/11 - Cálculo de Área </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula25">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula25'])){
                        
                          setcookie("ck-aula25-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula25-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/ilizwM1fm-g" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/ilizwM1fm-g" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        
            </div>

            <hr />
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula26"> Aula 26 - 01/12 </h3>
                <div class="row">  
                <div class="col">
                  <form action="calculo.php" method="POST">
                    <button class="btn btn-primary" style="50px;" type="submit" name="v-aula26">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <?php
                        if(isset($_POST['v-aula26'])){
                        
                          setcookie("ck-aula26-cal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula26-cal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                </div>
              </div>  
              <a href="https://www.youtube.com/embed/r3YnF1GbELs" target="_blank"> Clique
                    aqui para ver no YouTube </a><br />
                    <iframe width="720" height="480" src="https://www.youtube.com/embed/r3YnF1GbELs" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        
            </div>

        </div>
    </div>



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
</body>

</html>