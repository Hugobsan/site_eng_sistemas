<!doctype html>
<html lang="pt-br">

<head>
    <title>Aulas de GAAL</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/global_css.css">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <?php include_once("menu.php")  ?>
    <div class="submenu">
        <div class="regulasub">
            <a class="btn btn-dark" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false"
                aria-controls="collapseExample">
                <h3 class="text-info"><img src="caderneta.png" class="subimagem" />
                </h3>
            </a>
        </div>
        <div class="collapse bg-dark" id="collapseExample">
            <ul class="subcont text-white" style="list-style:none; text-align:right;">
                <a href="#aula1" class="text-white">
                    <li><b>Aula 01 - 19/08/2020</b></li>
                </a>
                <a href="#aula2" class="text-white">
                    <li><b>Aula 02 - 20/08/2020</b></li>
                </a>
                <a href="#aula3" class="text-white">
                    <li><b>Aula 03 - 22/08/2020</b></li>
                </a>
                <a href="#aula4" class="text-white">
                    <li><b>Aula 04 - 27/08/2020</b></li>
                </a>
                <a href="#aula5" class="text-white">
                    <li><b>Aula 05 - 29/08/2020</b></li>
                </a>
                <a href="#aula6" class="text-white">
                    <li><b>Aula 06 - 02/09/2020</b></li>
                </a>
                <a href="#aula7" class="text-white">
                    <li><b>Aula 07 - 09/09/2020</b></li>
                </a>
                <a href="#aula8" class="text-white">
                    <li><b>Aula 08 - 10/09/2020</b></li>
                </a>
                <a href="#aula9" class="text-white">
                    <li><b>Aula 09 - 16/09/2020</b></li>
                </a>
                <a href="#aula10" class="text-white">
                    <li><b>Aula 10 - 17/09/2020</b></li>
                </a>
                <a href="#aula11" class="text-white">
                    <li><b>Aula 11 - 23/09/2020</b></li>
                </a>
                <a href="#aula12" class="text-white">
                    <li><b>Aula 12 - 24/09/2020</b></li>
                </a>
            </ul>
        </div>
    </div>
    <div class="backgroundwpp">
    <div class="container">
        <div class="col-sm-11 abaixar2 col-lg-10 border border-primary rounded text-white">
            <h5> <a href="planejamento_gaal.pdf" target="_blank" class="text-dark">Clique para abrir o Planejamento de Aula de GAAL</a></h5>
        </div>
    </div>
        <div class="container">
            <div class="col-sm-12 col-lg-10">
                <h3 id="aula1"> Aula 01 - 19/08/2020 - Propriedades dos Determinantes </h3>
                <div class="row">
                    <div class="col">
                        <form action="gaal.php" method="POST">
                            <button class="btn btn-primary" type="submit" style="50px;" name="v-aula1">Marcar como
                                assistido</button>
                        </form>
                    </div>
                    <div class="col text-right">
                        <?php
                        if(isset($_POST['v-aula1'])){
                          setcookie("ck-aula1-gaal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula1-gaal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                    </div>
                </div>
                <a href="https://drive.google.com/file/d/1c42NIjC0WrfswM6nE1Gq9iMK7xkmZrIx/view" target="_blank"> Clique
                    aqui para ver no Drive </a><br />
                <iframe src="https://drive.google.com/file/d/1c42NIjC0WrfswM6nE1Gq9iMK7xkmZrIx/preview"
                    class="col-sm-12 col-lg-12" height="480"></iframe>
            </div>

            <hr />

            <div class="container">
                <div class="col-sm-12 col-lg-10">
                    <h3 id="aula2"> Aula 02 - 20/08/2020 - Cofatores, Laplace e Triangularização de Matrizes </h3>
                    <div class="row">
                        <div class="col">
                            <form action="gaal.php" method="POST">
                                <button class="btn btn-primary" type="submit" style="50px;" name="v-aula2">Marcar como
                                    assistido</button>
                            </form>
                        </div>
                        <div class="col text-right">
                            <?php
                        if(isset($_POST['v-aula2'])){
                          setcookie("ck-aula2-gaal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula2-gaal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                        </div>
                    </div>
                    <a href="https://drive.google.com/file/d/1wsFIhfLzDyII4TL36u9kjYN9OKhY8xSQ/view" target="_blank">
                        Clique
                        aqui para ver no Drive </a><br />
                    <iframe src="https://drive.google.com/file/d/1wsFIhfLzDyII4TL36u9kjYN9OKhY8xSQ/preview"
                        class="col-sm-12 col-lg-12" height="480"></iframe>
                </div>

            </div>

            <hr />

            <div class="container">
                <div class="col-sm-12 col-lg-10">
                    <h3 id="aula3"> Aula 03 - 22/08/2020 - Resolução de Exercicios </h3>
                    <div class="row">
                        <div class="col">
                            <form action="gaal.php" method="POST">
                                <button class="btn btn-primary" type="submit" style="50px;" name="v-aula3">Marcar como
                                    assistido</button>
                            </form>
                        </div>
                        <div class="col text-right">
                            <?php
                        if(isset($_POST['v-aula3'])){
                          setcookie("ck-aula3-gaal", "Verificado", (time() + (3600*24*30*12)));
                        }
                        if(isset($_COOKIE['ck-aula3-gaal'])){
                          echo '<img src="verifica.png" style="width:50px;">';
                        }
                    ?>
                        </div>
                    </div>
                    <a href="https://drive.google.com/file/d/1a-QXV8S8qirG-ct2uPg9t1E79r9EDUS1/view" target="_blank">
                        Clique
                        aqui para ver no Drive </a><br />
                    <iframe src="https://drive.google.com/file/d/1a-QXV8S8qirG-ct2uPg9t1E79r9EDUS1/preview"
                        class="col-sm-12 col-lg-12" height="480"></iframe>
                </div>

                <hr />

                <div class="container">
                    <div class="col-sm-12 col-lg-10">
                        <h3 id="aula4"> Aula 04 - 27/08/2020 - Somatório</h3>
                        <div class="row">
                            <div class="col">
                                <form action="gaal.php" method="POST">
                                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula4">Marcar como
                                        assistido</button>
                                </form>
                            </div>
                            <div class="col text-right">
                                <?php
                            if(isset($_POST['v-aula4'])){
                            setcookie("ck-aula4-gaal", "Verificado", (time() + (3600*24*30*12)));
                            }
                            if(isset($_COOKIE['ck-aula4-gaal'])){
                            echo '<img src="verifica.png" style="width:50px;">';
                            }
                        ?>
                            </div>
                        </div>
                        <a href="https://drive.google.com/file/d/1WiPhp-pu-awie0YGA8-HRuLM84R_BOut/view" target="_blank">
                            Clique
                            aqui para ver no Drive </a><br />
                        <iframe src="https://drive.google.com/file/d/1WiPhp-pu-awie0YGA8-HRuLM84R_BOut/preview"
                            class="col-sm-12 col-lg-12" height="480"></iframe>
                    </div>

                    <hr />

                <div class="container">
                    <div class="col-sm-12 col-lg-10">
                        <h3 id="aula5"> Aula 05 - 29/08/2020 </h3>
                        <div class="row">
                            <div class="col">
                                <form action="gaal.php" method="POST">
                                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula5">Marcar como
                                        assistido</button>
                                </form>
                            </div>
                            <div class="col text-right">
                                <?php
                            if(isset($_POST['v-aula5'])){
                            setcookie("ck-aula5-gaal", "Verificado", (time() + (3600*24*30*12)));
                            }
                            if(isset($_COOKIE['ck-aula5-gaal'])){
                            echo '<img src="verifica.png" style="width:50px;">';
                            }
                        ?>
                            </div>
                        </div>
                        <a href="https://drive.google.com/file/d/1HDj2tvDEqRAdq1kkoqYMhBQiyk9w8VFj/view" target="_blank">
                            Clique
                            aqui para ver no Drive </a><br />
                        <iframe src="https://drive.google.com/file/d/1HDj2tvDEqRAdq1kkoqYMhBQiyk9w8VFj/preview"
                            class="col-sm-12 col-lg-12" height="480"></iframe>
                    </div>

                    <hr />

                <div class="container">
                    <div class="col-sm-12 col-lg-10">
                        <h3 id="aula6"> Aula 06 - 02/09/2020 </h3>
                        <div class="row">
                            <div class="col">
                                <form action="gaal.php" method="POST">
                                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula6">Marcar como
                                        assistido</button>
                                </form>
                            </div>
                            <div class="col text-right">
                                <?php
                            if(isset($_POST['v-aula6'])){
                            setcookie("ck-aula6-gaal", "Verificado", (time() + (3600*24*30*12)));
                            }
                            if(isset($_COOKIE['ck-aula6-gaal'])){
                            echo '<img src="verifica.png" style="width:50px;">';
                            }
                        ?>
                            </div>
                        </div>
                        <a href="https://drive.google.com/file/d/10iYK_62BU2Hx8ns1sdhhQtWUTAPkhJxO/view" target="_blank">
                            Clique
                            aqui para ver no Drive </a><br />
                        <iframe src="https://drive.google.com/file/d/10iYK_62BU2Hx8ns1sdhhQtWUTAPkhJxO/preview"
                            class="col-sm-12 col-lg-12" height="480"></iframe>
                    </div>

                    <hr />

                <div class="container">
                    <div class="col-sm-12 col-lg-10">
                        <h3 id="aula7"> Aula 07 - 09/09/2020 </h3>
                        <div class="row">
                            <div class="col">
                                <form action="gaal.php" method="POST">
                                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula7">Marcar como
                                        assistido</button>
                                </form>
                            </div>
                            <div class="col text-right">
                                <?php
                            if(isset($_POST['v-aula7'])){
                            setcookie("ck-aula7-gaal", "Verificado", (time() + (3600*24*30*12)));
                            }
                            if(isset($_COOKIE['ck-aula7-gaal'])){
                            echo '<img src="verifica.png" style="width:50px;">';
                            }
                        ?>
                            </div>
                        </div>
                        <a href="https://drive.google.com/file/d/1qLFMSUozXnDkgIKRRqkv0X_CXQmtO8gI/view" target="_blank">
                            Clique
                            aqui para ver no Drive </a><br />
                        <iframe src="https://drive.google.com/file/d/1qLFMSUozXnDkgIKRRqkv0X_CXQmtO8gI/preview"
                            class="col-sm-12 col-lg-12" height="480"></iframe>
                    </div>

                    <hr />

                <div class="container">
                    <div class="col-sm-12 col-lg-10">
                        <h3 id="aula8"> Aula 08 - 09/09/2020 </h3>
                        <div class="row">
                            <div class="col">
                                <form action="gaal.php" method="POST">
                                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula8">Marcar como
                                        assistido</button>
                                </form>
                            </div>
                            <div class="col text-right">
                                <?php
                            if(isset($_POST['v-aula8'])){
                            setcookie("ck-aula8-gaal", "Verificado", (time() + (3600*24*30*12)));
                            }
                            if(isset($_COOKIE['ck-aula8-gaal'])){
                            echo '<img src="verifica.png" style="width:50px;">';
                            }
                        ?>
                            </div>
                        </div>
                        <a href="https://drive.google.com/file/d/1SOeCK5TF5HA4PEFHa2iJ2STr_ic9cNLo/view" target="_blank">
                            Clique
                            aqui para ver no Drive </a><br />
                        <iframe src="https://drive.google.com/file/d/1SOeCK5TF5HA4PEFHa2iJ2STr_ic9cNLo/preview"
                            class="col-sm-12 col-lg-12" height="480"></iframe>
                    </div>

                    <hr />

                <div class="container">
                    <div class="col-sm-12 col-lg-10">
                        <h3 id="aula9"> Aula 09 - 16/09/2020 </h3>
                        <div class="row">
                            <div class="col">
                                <form action="gaal.php" method="POST">
                                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula9">Marcar como
                                        assistido</button>
                                </form>
                            </div>
                            <div class="col text-right">
                                <?php
                            if(isset($_POST['v-aula9'])){
                            setcookie("ck-aula9-gaal", "Verificado", (time() + (3600*24*30*12)));
                            }
                            if(isset($_COOKIE['ck-aula9-gaal'])){
                            echo '<img src="verifica.png" style="width:50px;">';
                            }
                        ?>
                            </div>
                        </div>
                        <a href="https://drive.google.com/file/d/1Htn0CSzDVfTGkPt0b2w4PFs9vpx3Fd_l/view" target="_blank">
                            Clique
                            aqui para ver no Drive </a><br />
                        <iframe src="https://drive.google.com/file/d/1Htn0CSzDVfTGkPt0b2w4PFs9vpx3Fd_l/preview"
                            class="col-sm-12 col-lg-12" height="480"></iframe>
                    </div>

                    
                    <hr />

                <div class="container">
                    <div class="col-sm-12 col-lg-10">
                        <h3 id="aula10"> Aula 10 - 17/09/2020 </h3>
                        <div class="row">
                            <div class="col">
                                <form action="gaal.php" method="POST">
                                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula10">Marcar como
                                        assistido</button>
                                </form>
                            </div>
                            <div class="col text-right">
                                <?php
                            if(isset($_POST['v-aula10'])){
                            setcookie("ck-aula10-gaal", "Verificado", (time() + (3600*24*30*12)));
                            }
                            if(isset($_COOKIE['ck-aula10-gaal'])){
                            echo '<img src="verifica.png" style="width:50px;">';
                            }
                        ?>
                            </div>
                        </div>
                        <a href="https://drive.google.com/file/d/1H4qAtb1TWPHgVZurArAGbPzKR2BQc_yy/view" target="_blank">
                            Clique
                            aqui para ver no Drive </a><br />
                        <iframe src="https://drive.google.com/file/d/1H4qAtb1TWPHgVZurArAGbPzKR2BQc_yy/preview"
                            class="col-sm-12 col-lg-12" height="480"></iframe>
                    </div>

                    <hr />

                <div class="container">
                    <div class="col-sm-12 col-lg-10">
                        <h3 id="aula11"> Aula 11 - 23/09/2020 </h3>
                        <div class="row">
                            <div class="col">
                                <form action="gaal.php" method="POST">
                                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula11">Marcar como
                                        assistido</button>
                                </form>
                            </div>
                            <div class="col text-right">
                                <?php
                            if(isset($_POST['v-aula11'])){
                            setcookie("ck-aula11-gaal", "Verificado", (time() + (3600*24*30*12)));
                            }
                            if(isset($_COOKIE['ck-aula11-gaal'])){
                            echo '<img src="verifica.png" style="width:50px;">';
                            }
                        ?>
                            </div>
                        </div>
                        <a href="https://drive.google.com/file/d/1X1mwuIS043c6dyyTfDqWH0953SJYBt_M/view" target="_blank">
                            Clique
                            aqui para ver no Drive </a><br />
                        <iframe src="https://drive.google.com/file/d/1X1mwuIS043c6dyyTfDqWH0953SJYBt_M/preview"
                            class="col-sm-12 col-lg-12" height="480"></iframe>
                    </div>

                    <hr />

                <div class="container">
                    <div class="col-sm-12 col-lg-10">
                        <h3 id="aula12"> Aula 12 - 23/09/2020 </h3>
                        <div class="row">
                            <div class="col">
                                <form action="gaal.php" method="POST">
                                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula12">Marcar como
                                        assistido</button>
                                </form>
                            </div>
                            <div class="col text-right">
                                <?php
                            if(isset($_POST['v-aula12'])){
                            setcookie("ck-aula12-gaal", "Verificado", (time() + (3600*24*30*12)));
                            }
                            if(isset($_COOKIE['ck-aula12-gaal'])){
                            echo '<img src="verifica.png" style="width:50px;">';
                            }
                        ?>
                            </div>
                        </div>
                        <a href="https://drive.google.com/file/d/129RbagHRfBZJmkkXESU51DottyE7NOwp/view" target="_blank">
                            Clique
                            aqui para ver no Drive </a><br />
                        <iframe src="https://drive.google.com/file/d/129RbagHRfBZJmkkXESU51DottyE7NOwp/preview"
                            class="col-sm-12 col-lg-12" height="480"></iframe>
                    </div>



            </div>
        </div>


        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
            integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
            integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
        </script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
            integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
        </script>
</body>

</html>