
<!doctype html>
<html lang="pt-br">

<head>
  <title>Aulas de Sistemas Digitais</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <link rel="stylesheet" href="css/global_css.css">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <style>
    .backgroundwpp {
      background-image: url("wallpaper.jpg");
      background-color: #cccccc;
    }

    .abaixar {
      margin-top: 80px;
      background-color: #52bafa99;
      margin-bottom: 50px;
      padding-bottom: 20px;
    }
  </style>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
  <div class="container-fluid">
	<div class="justify-content-between row">
		<div class="logo  col-12 col-sm-12 col-md-4 col-lg-3 ">
			<h2>Engenharia de Sistemas Turma X<h2>
		</div>
		<div class="sublogo text-secondary  col-12 col-sm-12 col-md-4 col-lg-3 ">
			<h5 class="text-secondary">Site Improvisado e feito com pressa</h5>
		</div>
		<div class="navegador rounded col-12 col-sm-12 col-md-4 col-lg-5">
			<nav class="navbar navbar-expand-lg  ">
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
					<a class="navbar-brand" href="#">
						<img src="menu.png" alt="Menu">
					</a><a class="navbar-brand" href="#"></a>
				</button>
				<div class="collapse navbar-collapse justify-content-right hovermouse " id="collapsibleNavbar">
					<!-- Lista de itens do navbar -->
					<ul class="nav nav-pills navbar-nav abaixa">
						<li class="nav-item">
							<a class="nav-link azul-fraco" href="index.php">Principal</a>
						</li>
						<li class="nav-item">
							<a class="nav-link azul-fraco" href="calculo.php"> Aulas de Cálculo </a>
						</li>
						<li class="nav-item">
							<a class="nav-link azul-fraco" href="sd.php"> Aulas de Sistemas Digitais </a>
						</li>
						<li class="nav-item">
							<a class="nav-link azul-fraco" href="gaal.php"> Aulas de GAAL </a>
						</li>

					</ul>
				</div>
			</nav>
		</div>
	</div>
</div>
<hr>
<!-- Fim do Cabeçalho -->  
<div class="submenu">
    <div class="regulasub">
      <a class="btn btn-dark" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
        <h3 class="text-info"><img src="caderneta.png" class="subimagem" />
        </h3>
      </a>
    </div>
  
    <div class="collapse bg-dark" id="collapseExample">
      <ul class="subcont text-white" style="list-style:none; text-align:right;">
        <a href="#aula1sd" class="text-white">
          <li><b>Vídeo da aula de 25/03/2020</b></li>
        </a>
        <a href="#aula2sd" class="text-white">
          <li><b>Vídeo da aula de 01/04/2020</b></li>
        </a>
        <a href="#aula3sd" class="text-white">
          <li><b>Vídeo da aula de 08/04/2020</b></li>
        </a>
        <a href="#aula4sd" class="text-white">
          <li><b>Vídeo da aula de 15/04/2020</b></li>
        </a>
        <a href="#aula5sd" class="text-white">
          <li><b>Vídeo da aula de 22/04/2020</b></li>
        </a>
        <a href="#aula6sd" class="text-white">
          <li><b>Vídeo da aula de 29/04/2020</b></li>
        </a>
        <a href="#aula7sd" class="text-white">
          <li><b>Vídeo da aula de 06/05/2020</b></li>
        </a>
        <a href="#aula8sd" class="text-white">
          <li><b>Vídeo da aula de 13/05/2020</b></li>
        </a>
        <a href="#aula9sd" class="text-white">
          <li><b>Vídeo da aula de 17/06/2020</b></li>
        </a>
        <a href="#aula10sd" class="text-white">
          <li><b>Vídeo da aula de 24/06/2020</b></li>
        </a>
        <a href="#aula11sd" class="text-white">
          <li><b>Vídeo da aula de 01/07/2020</b></li>
        </a>
        <a href="#aula12sd" class="text-white">
          <li><b>Vídeo da aula de 08/07/2020</b></li>
        </a>
        <a href="#aula13sd" class="text-white">
          <li><b>Vídeo da aula de 19/08/2020</b></li>
        </a>
        <a href="#aula14sd" class="text-white">
          <li><b>Vídeo da aula de 26/08/2020</b></li>
        </a>
        <a href="#aula15sd" class="text-white">
          <li><b>Vídeo da aula de 02/09/2020</b></li>
        </a>
        <a href="#aula16sd" class="text-white">
          <li><b>Vídeo da aula de 09/09/2020</b></li>
        </a>
        <a href="#aula17sd" class="text-white">
          <li><b>Vídeo da aula de 16/09/2020</b></li>
        </a>
      </ul>
    </div>
  </div>
  <div class="backgroundwpp">
  <div class="container">
    <div class="col-sm-11 abaixar2 col-lg-10 border border-primary rounded text-white">
        <h5><a href="slides-pdfs.rar" target="_blank" class="text-dark">Clique para baixar os Slides de SD</a></h5>
    </div>
  <div class="container">
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula1sd"> Vídeo da aula de 25/03/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula1">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <img src="verifica.png" style="width:50px;">                </div>
              </div>  
        <a href="https://drive.google.com/file/d/1gseKfgWJNQniRZIA39tUlUVqtWBNzo20/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1gseKfgWJNQniRZIA39tUlUVqtWBNzo20/preview" class="col-12" height="480"></iframe>
      </div>
    <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula2sd"> Vídeo da aula de 01/04/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula2">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <img src="verifica.png" style="width:50px;">                </div>
              </div>  
        <a href="https://drive.google.com/file/d/1dFM2ozWBEbGq1gsGUUVXrrl4cvOJPFgz/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1dFM2ozWBEbGq1gsGUUVXrrl4cvOJPFgz/preview" class="col-12" height="480"></iframe>
      </div>
      <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula3sd"> Vídeo da aula de 08/04/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula3">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <img src="verifica.png" style="width:50px;">                </div>
              </div>  
        <a href="https://drive.google.com/file/d/1HfYNW2BZ15qolmrSIiviJw9TdISacI_G/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1HfYNW2BZ15qolmrSIiviJw9TdISacI_G/preview" class="col-12" height="480"></iframe>
      </div>
      <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula4sd"> Vídeo da aula de 15/04/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula4">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <img src="verifica.png" style="width:50px;">                </div>
              </div>  
        <a href="https://drive.google.com/file/d/1kxbgKI4DiS8F0Tu-t-8dSrkNXQQTNhie/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1kxbgKI4DiS8F0Tu-t-8dSrkNXQQTNhie/preview" class="col-12" height="480"></iframe>
      </div>
      <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula5sd"> Vídeo da aula de 22/04/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula5">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <img src="verifica.png" style="width:50px;">                </div>
              </div>  
        <a href="https://drive.google.com/file/d/1L0LOUC4xPECwJD6l78QtzPENR_KSkRPZ/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1L0LOUC4xPECwJD6l78QtzPENR_KSkRPZ/preview" class="col-12" height="480"></iframe>
      </div>
      <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula6sd"> Vídeo da aula de 29/04/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula6">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <img src="verifica.png" style="width:50px;">                </div>
              </div>  
        <a href="https://drive.google.com/file/d/1aCiHNQuG8GYDLLkxG05PJKDyeMf0WiXh/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1aCiHNQuG8GYDLLkxG05PJKDyeMf0WiXh/preview" class="col-12" height="480"></iframe>
      </div>
      <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula7sd"> Vídeo da aula de 06/05/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula7">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <img src="verifica.png" style="width:50px;">                </div>
              </div>  
        <a href="https://drive.google.com/file/d/1CKrfYPYA4PsWHNJyCPkxxMpS0Mz9l0Os/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1CKrfYPYA4PsWHNJyCPkxxMpS0Mz9l0Os/preview" class="col-12" height="480"></iframe>
      </div>
      <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula8sd"> Vídeo da aula de 13/05/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula8">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <img src="verifica.png" style="width:50px;">                </div>
              </div>  
        <a href="https://drive.google.com/file/d/1HTGSELNvblc7p0chYVqN2vUT0WCWpP-9/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1HTGSELNvblc7p0chYVqN2vUT0WCWpP-9/preview" class="col-12" height="480"></iframe>
      </div>
      <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula9sd"> Vídeo da aula de 17/06/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula9">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <img src="verifica.png" style="width:50px;">                </div>
              </div>  
        <a href="https://drive.google.com/file/d/1XTpYy0c3tFD2yVyi1lLOnNGRol_JXZ0r/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1XTpYy0c3tFD2yVyi1lLOnNGRol_JXZ0r/preview" class="col-12" height="480"></iframe>
      </div>
      <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula10sd"> Vídeo da aula de 24/06/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula10">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                  <img src="verifica.png" style="width:50px;">                </div>
              </div>  
        <a href="https://drive.google.com/file/d/10JUSBw6T1TCAOmXoq6CKN_F6PBYRS58x/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/10JUSBw6T1TCAOmXoq6CKN_F6PBYRS58x/preview" class="col-12" height="480"></iframe>
      </div>
      <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula11sd"> Vídeo da aula de 01/07/2020 (Gravação Parcial Devido à perda de conexão) </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula11">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                                  </div>
              </div>  
        <a href="https://drive.google.com/file/d/1rKc9AXUArXIcHg0SApcYmwmwdLp-CbWt/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1rKc9AXUArXIcHg0SApcYmwmwdLp-CbWt/preview" class="col-12" height="480"></iframe>
      </div>

      <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula12sd"> Vídeo da aula de 08/07/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula12">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                                  </div>
              </div>  
        <a href="https://drive.google.com/file/d/1to_23k9aBNVytycuNdhSZndTvGu8RPAM/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1to_23k9aBNVytycuNdhSZndTvGu8RPAM/preview" class="col-12" height="480"></iframe>
      </div>

      <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula13sd"> Vídeo da aula de 19/08/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula13">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                                  </div>
              </div>  
        <a href="https://drive.google.com/file/d/1CEeJkp-uXjQjK-MVnTDj77rFG1audMyo/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1CEeJkp-uXjQjK-MVnTDj77rFG1audMyo/preview" class="col-12" height="480"></iframe>
      </div>
      
      <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula14sd"> Vídeo da aula de 26/08/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula14">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                                  </div>
              </div>  
        <a href="https://drive.google.com/file/d/1GImtr5dV3yK5uvYtfWS3NrC3Bb1mgkio/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1GImtr5dV3yK5uvYtfWS3NrC3Bb1mgkio/preview" class="col-12" height="480"></iframe>
      </div>

      <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula15sd"> Vídeo da aula de 02/09/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula15">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                                  </div>
              </div>  
        <a href="https://drive.google.com/file/d/1W29dkAMUBUd2OjnArNZRr1UzJln5jsGd/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1W29dkAMUBUd2OjnArNZRr1UzJln5jsGd/preview" class="col-12" height="480"></iframe>
      </div>

      <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula16sd"> Vídeo da aula de 09/09/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula16">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                                  </div>
              </div>  
        <a href="https://drive.google.com/file/d/1YqkZ-2GEoVbrop1yxI7NRx_4Bce16Fvh/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1YqkZ-2GEoVbrop1yxI7NRx_4Bce16Fvh/preview" class="col-12" height="480"></iframe>
      </div>

      <hr />
      <div class="col-sm-12 col-lg-10">
        <h3 id="aula17sd"> Vídeo da aula de 16/09/2020 </h3>
        <div class="row">  
                <div class="col">
                  <form action="sd.php" method="POST">
                    <button class="btn btn-primary" type="submit" style="50px;" name="v-aula17">Marcar como assistido</button>
                  </form>
                </div>
                <div class="col text-right">
                                  </div>
              </div>  
        <a href="https://drive.google.com/file/d/1x-b23dnaolnlReER53eWUbq8M3vJFaYJ/view" target="_blank"> Clique aqui para ver no Drive </a><br />
        <iframe src="https://drive.google.com/file/d/1x-b23dnaolnlReER53eWUbq8M3vJFaYJ/preview" class="col-12" height="480"></iframe>
      </div>
    
    
    </div>
  </div>



  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<div style="text-align:right;position:fixed;bottom:3px;right:3px;width:100%;z-index:999999;cursor:pointer;line-height:0;display:block;"><a target="_blank" href="https://www.freewebhostingarea.com" title="Free Web Hosting with PHP5 or PHP7"><img alt="Free Web Hosting" src="https://www.freewebhostingarea.com/images/poweredby.png" style="border-width: 0px;width: 180px; height: 45px; float: right;"></a></div>
</body>

</html>