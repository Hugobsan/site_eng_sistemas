<div class="container">
    <div class="col-sm-11 abaixar2 col-lg-10 border border-primary rounded text-white">
        <h5><a href="https://drive.google.com/drive/folders/1DujCGbFjZp13EAV_U2oROphwL3GXlej7?usp=sharing" target="_blank" class="text-dark">Clique Para Abrir a Biblioteca da Turma X</a> (NOVO!)</h5>
        <h5><a href="" target="_blank" class="text-dark"></a></h5>
    </div>
</div>