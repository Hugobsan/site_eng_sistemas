<div class="container-fluid">
	<div class="justify-content-between row">
		<div class="logo  col-12 col-sm-12 col-md-4 col-lg-3 ">
			<h2>Engenharia de Sistemas Turma X<h2>
		</div>
		<div class="sublogo text-secondary  col-12 col-sm-12 col-md-4 col-lg-3 ">
			<h5 class="text-secondary">Site Improvisado e feito com pressa</h5>
		</div>
		<div class="navegador rounded col-12 col-sm-12 col-md-4 col-lg-5">
			<nav class="navbar navbar-expand-lg  ">
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
					<a class="navbar-brand" href="#">
						<img src="menu.png" alt="Menu">
					</a><a class="navbar-brand" href="#"></a>
				</button>
				<div class="collapse navbar-collapse justify-content-right hovermouse " id="collapsibleNavbar">
					<!-- Lista de itens do navbar -->
					<ul class="nav nav-pills navbar-nav abaixa">
						<li class="nav-item">
							<a class="nav-link azul-fraco" href="index.php">Principal</a>
						</li>
						<li class="nav-item">
							<a class="nav-link azul-fraco" href="calculo.php"> Aulas de Cálculo </a>
						</li>
						<li class="nav-item">
							<a class="nav-link azul-fraco" href="sd.php"> Aulas de Sistemas Digitais </a>
						</li>
						<li class="nav-item">
							<a class="nav-link azul-fraco" href="gaal.php"> Aulas de GAAL </a>
						</li>

					</ul>
				</div>
			</nav>
		</div>
	</div>
</div>
<hr>
<!-- Fim do Cabeçalho -->